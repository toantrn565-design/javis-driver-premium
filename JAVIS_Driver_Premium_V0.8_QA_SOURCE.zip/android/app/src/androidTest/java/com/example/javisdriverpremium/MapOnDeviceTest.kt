package com.example.javisdriverpremium

import android.webkit.WebView
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.example.javisdriverpremium.ui.MapTileClient
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Exercises the packaged WebView map and actual tile loading on an Android emulator. */
@RunWith(AndroidJUnit4::class)
class MapOnDeviceTest {
    @Test fun roadMapDisplaysRealPixelsAndRoute() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val packageName = instrumentation.targetContext.packageName
        for (permission in listOf("android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION", "android.permission.POST_NOTIFICATIONS")) {
            instrumentation.uiAutomation.executeShellCommand("pm grant $packageName $permission").close()
        }
        val scenario = ActivityScenario.launch(MainActivity::class.java)
        lateinit var webView: WebView
        try {
            scenario.onActivity { activity ->
                webView = WebView(activity).apply {
                    settings.javaScriptEnabled = true
                    webViewClient = MapTileClient()
                }
                activity.setContentView(webView)
                webView.loadUrl("file:///android_asset/driver_map.html")
            }
            // Android WebView loads the local page asynchronously; retry after layout.
            var result = ""
            for (attempt in 1..40) {
                result = evaluate(webView, """(function(){
                  if (typeof updateMap !== 'function') return 'waiting';
                  updateMap(21.0285,105.8542,'road','');
                  updateRoute([[21.0285,105.8542],[21.03,105.86]]);
                  const tiles=[...document.querySelectorAll('img.tile')];
                  return JSON.stringify({width:document.getElementById('map').clientWidth,
                    loaded:tiles.filter(x=>x.complete&&x.naturalWidth>0).length,
                    requested:tiles.length,route:routePoints.length,
                    status:document.getElementById('status').textContent});
                })()""")
                if (result.contains("\\\"loaded\\\":") && !result.contains("\\\"loaded\\\":0")) break
                Thread.sleep(500)
            }
            val screenshot = instrumentation.uiAutomation.takeScreenshot()
            val path = File(instrumentation.targetContext.getExternalFilesDir(null), "javis-map-emulator.png")
            FileOutputStream(path).use { screenshot.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            screenshot.recycle()
            assertTrue("Map requires downloaded tile pixels; WebView result: $result", result.contains("\\\"loaded\\\":") && !result.contains("\\\"loaded\\\":0"))
            assertTrue("Route geometry must reach the map: $result", result.contains("\\\"route\\\":2"))
        } finally {
            scenario.close()
        }
    }

    private fun evaluate(view: WebView, script: String): String {
        val latch = CountDownLatch(1)
        var result = ""
        view.post { view.evaluateJavascript(script) { result = it; latch.countDown() } }
        assertTrue("WebView JavaScript timed out", latch.await(10, TimeUnit.SECONDS))
        return result
    }
}
