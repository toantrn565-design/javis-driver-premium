# JAVIS Driver V0.3 — map test

Changes: road map (OpenStreetMap), detailed humanitarian map (OpenStreetMap France), satellite imagery (optional user supplied MapTiler API key), voice destination input, simplified driving controls.

Current route guidance opens the installed maps application. The in-app map follows GPS and supports pan/zoom, but does not show a route polyline or announce turns. The approved camera file is `[]`; do not treat the absence of a warning as proof that a route has no cameras. A verified, direction-aware dataset is required before road camera alerts work.

Build: Android Studio with JDK 17, Android SDK API 36 and network access, or push branch `driver-v03-maps` to GitHub to trigger `.github/workflows/android-test-apk.yml`. Build command: `cd android && ./gradlew :app:testDebugUnitTest :app:assembleDebug`. Output: `android/app/build/outputs/apk/debug/app-debug.apk`.

This workspace could not resolve `org.gradle.toolchains.foojay-resolver-convention:1.0.0` because remote Gradle repositories are inaccessible; no V0.3 APK was generated here. Do not distribute V0.1 APK as V0.3.
