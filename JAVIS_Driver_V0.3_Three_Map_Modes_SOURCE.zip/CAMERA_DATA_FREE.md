# Nguồn camera miễn phí: Hà Nội và Phú Thọ

Nguồn: OpenStreetMap, giấy phép ODbL 1.0. Tập `camera_points.json` được công bố
cùng mã nguồn theo ODbL nếu phân phối bản dữ liệu dẫn xuất. Trên app hiển thị ghi nguồn
`© OpenStreetMap contributors (ODbL)`; xem https://www.openstreetmap.org/copyright.

## Luồng dữ liệu

1. Chạy bằng máy có Internet (Python 3, không cần API key):
   `python3 tools/import_osm_cameras.py --candidates camera_review.csv`
   Script truy vấn 2 khu vực hành chính cấp tỉnh `Hà Nội` và `Phú Thọ`, tìm
   `highway=speed_camera` và quan hệ `type=enforcement`. Mỗi lần chạy chỉ có
   2 truy vấn; không gọi Overpass liên tục từ điện thoại.
2. Mở `camera_review.csv` và đối chiếu vị trí thực tế trên đường đi. Trường
   `osm_direction_raw` là hướng thiết bị được gắn trên OSM; **không** mặc định
   đó là chiều xe chạy. Chỉ sau khi xác định đúng là camera xử lý vi phạm,
   đúng nhánh đường và chiều xe bị ghi nhận, nhập `direction_deg` (0–359,
   heading của xe theo chiều bị giám sát), `verification_note` (bằng chứng,
   ngày kiểm tra) và `review_status=VERIFIED`. Nhập `speed_limit_kmh` khi đã
   kiểm tra biển tốc độ; để trống nếu chưa rõ. Các camera giám sát thông
   thường, camera quan sát ùn tắc không được nhận là camera phạt nguội.
3. Xuất dữ liệu đã kiểm tra:
   `python3 tools/import_osm_cameras.py --approve camera_review.csv --output android/app/src/main/assets/camera_points.json`
4. Chạy `python3 -m unittest discover -s tools -p 'test_*.py'`, sau đó build
   Android. APK lưu các điểm đã kiểm tra để cảnh báo offline; muốn cập nhật
   cần chạy lại bước 1–3 và phát hành APK mới.

`camera_points.json` hiện là `[]`. Chưa có camera nào được xác nhận, nên
**Bản build từ mã hiện tại không phát cảnh báo camera ở chế độ thực tế**. Số điểm được duyệt
hiển thị trên màn hình chính. App lọc điểm ngược chiều, phía sau và khử lặp
theo bộ máy cảnh báo sẵn có. Việc không có cảnh báo không chứng minh đoạn
đường không có camera.

GPS và góc hướng không đủ để phân biệt hoàn toàn các đường song song hoặc
đường gom. Bản thử chỉ dùng để kiểm chứng trên cung đường cụ thể; trước khi
quảng bá độ chính xác, cần bổ sung dữ liệu hình học đoạn đường và khớp tuyến
cho từng camera.

Trước mỗi bản phát hành, nên kiểm tra lại danh sách OSM cũ, các điểm vừa bị
xóa/sửa và ngày xác minh. Nếu chưa chắc, trả điểm về `PENDING` để không đóng
gói. Không sao chép cơ sở dữ liệu từ ứng dụng thương mại khác.
