package com.example.javisdriverpremium

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.net.Uri
import android.speech.RecognizerIntent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.example.javisdriverpremium.model.GpsQuality
import com.example.javisdriverpremium.model.ReportType
import com.example.javisdriverpremium.service.DrivingForegroundService
import com.example.javisdriverpremium.service.DrivingState
import com.example.javisdriverpremium.theme.JavisDriverPremiumTheme
import com.example.javisdriverpremium.ui.JavisDriverApp
import kotlinx.coroutines.flow.MutableStateFlow

class MainActivity : ComponentActivity() {

    private var drivingService by mutableStateOf<DrivingForegroundService?>(null)
    private var isBound = false
    private val fallbackState = MutableStateFlow(DrivingState())
    private var voiceDestination by mutableStateOf<String?>(null)

    private val voiceDestinationLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) voiceDestination = spoken
        }
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as DrivingForegroundService.LocalBinder
            drivingService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            drivingService = null
            isBound = false
        }
    }

    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false

        if (!fineGranted && !coarseGranted) {
            Toast.makeText(
                this,
                "Cần quyền định vị để JAVIS Driver đo tốc độ và cảnh báo.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen on while driving
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Request required permissions
        checkAndRequestPermissions()

        // Binding creates the service; only start it as a foreground service after
        // the driver grants location and explicitly starts a trip.
        val intent = Intent(this, DrivingForegroundService::class.java)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)

        setContent {
            JavisDriverPremiumTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val state by (drivingService?.drivingState ?: fallbackState).collectAsState()

                    JavisDriverApp(
                        drivingState = state,
                        onStartDrive = { useTestFixture ->
                            if (hasLocationPermission()) {
                                drivingService?.let { service ->
                                    ContextCompat.startForegroundService(this, intent)
                                    service.startDriving(useTestFixture)
                                } ?: Toast.makeText(this, "Đang kết nối GPS, vui lòng thử lại.", Toast.LENGTH_SHORT).show()
                            } else {
                                checkAndRequestPermissions()
                            }
                        },
                        onEndDrive = {
                            drivingService?.stopDriving()
                        },
                        onReportSubmit = { reportType ->
                            drivingService?.submitReport(reportType)
                        },
                        onSimulateGps = { sample ->
                            drivingService?.processSimulatedGpsSample(sample)
                        },
                        onNavigate = { destination -> openNavigation(destination) },
                        onVoiceDestination = { requestVoiceDestination() },
                        voiceDestination = voiceDestination
                    )
                }
            }
        }
    }

    private fun openNavigation(destination: String) {
        val target = destination.trim()
        if (target.isEmpty()) {
            Toast.makeText(this, "Nhập điểm đến để bắt đầu chỉ đường.", Toast.LENGTH_SHORT).show()
            return
        }
        val maps = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${Uri.encode(target)}"))
            .setPackage("com.google.android.apps.maps")
        val fallback = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(target)}"))
        try {
            startActivity(maps)
        } catch (_: android.content.ActivityNotFoundException) {
            try {
                startActivity(fallback)
            } catch (_: android.content.ActivityNotFoundException) {
                Toast.makeText(this, "Cần cài ứng dụng bản đồ để chỉ đường.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun requestVoiceDestination() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Anh muốn đi đâu?")
        }
        try {
            voiceDestinationLauncher.launch(intent)
        } catch (_: android.content.ActivityNotFoundException) {
            Toast.makeText(this, "Thiết bị chưa có ứng dụng nhận giọng nói.", Toast.LENGTH_LONG).show()
        }
    }

    private fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        return fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED
    }

    private fun checkAndRequestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        requestPermissionsLauncher.launch(permissions.toTypedArray())
    }

    override fun onDestroy() {
        if (isBound) {
            unbindService(serviceConnection)
            isBound = false
        }
        super.onDestroy()
    }
}
