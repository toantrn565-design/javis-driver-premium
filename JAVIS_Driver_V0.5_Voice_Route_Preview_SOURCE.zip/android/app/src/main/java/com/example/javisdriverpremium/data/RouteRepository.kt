package com.example.javisdriverpremium.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class RouteStep(val lat: Double, val lng: Double, val instruction: String)
data class RoutePlan(val points: List<Pair<Double, Double>>, val steps: List<RouteStep>, val meters: Double, val seconds: Double)

/** Preview service for a single submitted destination. Call from Dispatchers.IO only. */
object RouteRepository {
    fun plan(context: Context, originLat: Double, originLng: Double, destination: String): RoutePlan {
        val target = destination.trim().take(180)
        require(target.length >= 3) { "Nhập điểm đến cụ thể hơn." }
        require(originLat in -90.0..90.0 && originLng in -180.0..180.0)
        val search = JSONArray(read("https://nominatim.openstreetmap.org/search?q=${URLEncoder.encode(target, "UTF-8")}&format=json&limit=1&countrycodes=vn"))
        require(search.length() > 0) { "Không tìm thấy điểm đến tại Việt Nam." }
        val location = search.getJSONObject(0)
        val routeData = JSONObject(read("https://router.project-osrm.org/route/v1/driving/$originLng,$originLat;${location.getDouble("lon")},${location.getDouble("lat")}?overview=full&geometries=geojson&steps=true"))
        require(routeData.optString("code") == "Ok") { "Không tìm được tuyến đường lái xe." }
        val route = routeData.getJSONArray("routes").getJSONObject(0)
        val geometry = route.getJSONObject("geometry").getJSONArray("coordinates")
        val points = (0 until geometry.length()).map { i -> geometry.getJSONArray(i).let { it.getDouble(1) to it.getDouble(0) } }
        val steps = mutableListOf<RouteStep>()
        val legs = route.getJSONArray("legs")
        for (i in 0 until legs.length()) {
            val list = legs.getJSONObject(i).getJSONArray("steps")
            for (j in 0 until list.length()) {
                val step = list.getJSONObject(j)
                val maneuver = step.getJSONObject("maneuver")
                val place = maneuver.getJSONArray("location")
                val instruction = when (maneuver.optString("modifier")) {
                    "left", "slight left", "sharp left" -> "Rẽ trái"
                    "right", "slight right", "sharp right" -> "Rẽ phải"
                    "uturn" -> "Quay đầu"
                    else -> if (maneuver.optString("type") == "arrive") "Đã đến nơi" else "Đi tiếp"
                }
                val road = step.optString("name")
                steps += RouteStep(place.getDouble(1), place.getDouble(0), if (road.isBlank()) instruction else "$instruction vào $road")
            }
        }
        require(points.size > 1)
        return RoutePlan(points, steps, route.getDouble("distance"), route.getDouble("duration"))
    }

    private fun read(address: String): String {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 8_000
        connection.readTimeout = 12_000
        connection.setRequestProperty("User-Agent", "JAVISDriverPreview/0.4 (https://github.com/toantrn565-design/javis-driver-premium)")
        try {
            require(connection.responseCode in 200..299) { "Dịch vụ tuyến đường không phản hồi (${connection.responseCode})." }
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally { connection.disconnect() }
    }
}
