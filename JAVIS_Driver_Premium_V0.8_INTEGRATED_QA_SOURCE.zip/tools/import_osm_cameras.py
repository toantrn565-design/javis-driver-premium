#!/usr/bin/env python3
"""Fetch OSM camera candidates for Hanoi and Phu Tho; export audited points.

Fetching creates a review CSV only. A separate, explicit --approve operation
converts reviewed rows to the Android asset. No OSM point is auto-verified.
"""
import argparse
import csv
import json
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ENDPOINT = "https://overpass-api.de/api/interpreter"
AREAS = ("Hà Nội", "Phú Thọ")
FIELDS = ("osm_id", "area", "latitude", "longitude", "camera_type", "osm_direction_raw", "direction_deg",
          "osm_maxspeed_raw", "speed_limit_kmh", "osm_url", "review_status", "verification_note")


def query_for(area):
    safe_name = area.replace('"', '\\"')
    return (f'[out:json][timeout:90];area["boundary"="administrative"]'
            f'["admin_level"="4"]["name"="{safe_name}"]->.a;'
            '(node["highway"="speed_camera"](area.a);'
            'relation["type"="enforcement"](area.a););out center;')


def fetch(area):
    data = urllib.parse.urlencode({"data": query_for(area)}).encode()
    request = urllib.request.Request(ENDPOINT, data=data, headers={
        "User-Agent": "JavisDriverCameraReview/0.2 (manual OSM data review)"})
    with urllib.request.urlopen(request, timeout=120) as response:
        return json.load(response)


def candidates(payload, area):
    result = []
    for item in payload.get("elements", []):
        tags = item.get("tags", {})
        camera_type = "SPEED_CAMERA" if tags.get("highway") == "speed_camera" or tags.get("enforcement") == "maxspeed" else "RED_LIGHT_CAMERA" if tags.get("enforcement") == "traffic_signals" else None
        pos = item.get("center", item)
        if camera_type is None or "lat" not in pos or "lon" not in pos:
            continue
        osm_type = item.get("type")
        osm_id = item.get("id")
        if osm_type not in ("node", "relation") or not isinstance(osm_id, int):
            continue
        result.append({
            "osm_id": f"{osm_type}/{osm_id}", "area": area,
            "latitude": pos["lat"], "longitude": pos["lon"],
            "camera_type": camera_type, "osm_direction_raw": tags.get("direction", ""),
            "direction_deg": "",
            "osm_maxspeed_raw": tags.get("maxspeed", ""), "speed_limit_kmh": "",
            "osm_url": f"https://www.openstreetmap.org/{osm_type}/{osm_id}",
            "review_status": "PENDING", "verification_note": ""
        })
    return result


def write_candidates(out):
    records = {}
    for area in AREAS:
        for row in candidates(fetch(area), area):
            records[row["osm_id"]] = row
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(sorted(records.values(), key=lambda r: (r["area"], r["osm_id"])))
    print(f"Wrote {len(records)} unverified candidates: {out}")


def approve(review, out):
    approved = []
    seen = set()
    with review.open(newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            if row["review_status"].strip().upper() != "VERIFIED":
                continue
            osm_id = row["osm_id"].strip()
            if osm_id in seen or not osm_id.startswith(("node/", "relation/")):
                raise ValueError(f"Duplicate or invalid OSM ID: {osm_id}")
            seen.add(osm_id)
            if not row["verification_note"].strip():
                raise ValueError(f"Verification evidence is missing: {osm_id}")
            if row["area"] not in AREAS:
                raise ValueError(f"Unexpected area: {osm_id}")
            latitude, longitude = float(row["latitude"]), float(row["longitude"])
            if not (19.0 <= latitude <= 23.0 and 103.0 <= longitude <= 107.0):
                raise ValueError(f"Invalid Vietnam location: {osm_id}")
            try:
                direction = float(row["direction_deg"])
            except ValueError as error:
                raise ValueError(f"Driving direction is missing: {osm_id}") from error
            if not 0 <= direction < 360:
                raise ValueError(f"Driving direction is missing: {osm_id}")
            if row["camera_type"] not in ("SPEED_CAMERA", "RED_LIGHT_CAMERA"):
                raise ValueError(f"Invalid camera type: {osm_id}")
            if row["osm_url"].strip() != f"https://www.openstreetmap.org/{osm_id}":
                raise ValueError(f"Invalid OSM source: {osm_id}")
            speed = row["speed_limit_kmh"].strip()
            if speed and (not speed.isdigit() or not 10 <= int(speed) <= 130):
                raise ValueError(f"Invalid speed limit: {osm_id}")
            approved.append({
                "id": f"OSM_{osm_id.replace('/', '_')}", "lat": latitude,
                "lng": longitude, "type": row["camera_type"],
                "direction": direction, "speedLimitKm": int(speed) if speed else None,
                "verificationStatus": "VERIFIED", "source": row["osm_url"],
                "lastVerified": int(datetime.now(timezone.utc).timestamp() * 1000)
            })
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(approved, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {len(approved)} reviewed cameras: {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidates", type=Path, help="Fetch OSM into a review CSV")
    parser.add_argument("--approve", type=Path, help="Review CSV with VERIFIED rows and evidence")
    parser.add_argument("--output", type=Path, help="Android JSON output path")
    args = parser.parse_args()
    if args.candidates and not args.approve:
        write_candidates(args.candidates)
    elif args.approve and args.output and not args.candidates:
        approve(args.approve, args.output)
    else:
        parser.error("Use --candidates FILE or --approve REVIEW.csv --output ASSET.json")
