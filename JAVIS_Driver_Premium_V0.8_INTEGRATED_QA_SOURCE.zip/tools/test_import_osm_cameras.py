import csv
import tempfile
import unittest
from pathlib import Path

from import_osm_cameras import FIELDS, approve, candidates


class CameraImportTest(unittest.TestCase):
    def test_osm_points_stay_unverified_and_direction_requires_review(self):
        payload = {"elements": [{"type": "node", "id": 42, "lat": 21.03, "lon": 105.8,
                                 "tags": {"highway": "speed_camera", "direction": "90", "maxspeed": "60"}}]}
        point, = candidates(payload, "Hà Nội")
        self.assertEqual(point["review_status"], "PENDING")
        self.assertEqual(point["osm_direction_raw"], "90")
        self.assertEqual(point["direction_deg"], "")
        self.assertEqual(point["speed_limit_kmh"], "")

        with tempfile.TemporaryDirectory() as temp:
            review, output = Path(temp) / "review.csv", Path(temp) / "camera_points.json"
            with review.open("w", newline="", encoding="utf-8") as file:
                writer = csv.DictWriter(file, fieldnames=FIELDS)
                writer.writeheader()
                writer.writerow({**point, "review_status": "VERIFIED", "verification_note": "Checked on site"})
            with self.assertRaisesRegex(ValueError, "Driving direction"):
                approve(review, output)
            self.assertFalse(output.exists())
            point.update(review_status="VERIFIED", verification_note="Checked on site",
                         direction_deg="90", speed_limit_kmh="60")
            with review.open("w", newline="", encoding="utf-8") as file:
                writer = csv.DictWriter(file, fieldnames=FIELDS)
                writer.writeheader()
                writer.writerow(point)
            approve(review, output)
            self.assertIn('"verificationStatus": "VERIFIED"', output.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
