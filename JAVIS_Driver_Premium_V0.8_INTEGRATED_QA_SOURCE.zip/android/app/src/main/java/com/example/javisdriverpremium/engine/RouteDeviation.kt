package com.example.javisdriverpremium.engine

import kotlin.math.cos

object RouteDeviation {
    data class Position(val segmentIndex: Int, val fraction: Double, val distanceMeters: Float)

    /** Distance to route geometry, not to the next maneuver or final destination. */
    fun meters(lat: Double, lng: Double, points: List<Pair<Double, Double>>): Float =
        nearest(lat, lng, points).distanceMeters

    fun nearest(lat: Double, lng: Double, points: List<Pair<Double, Double>>): Position {
        if (points.size < 2) return Position(0, 0.0, Float.POSITIVE_INFINITY)
        var closest = Position(0, 0.0, Float.POSITIVE_INFINITY)
        for (index in 0 until points.lastIndex) {
            val a = points[index]
            val b = points[index + 1]
            val distance = GeoUtils.distanceToSegmentMeters(lat, lng, a.first, a.second, b.first, b.second)
            if (distance < closest.distanceMeters) {
                val latitudeScale = 111_132.92
                val longitudeScale = 111_412.84 * cos(Math.toRadians((a.first + b.first) / 2))
                val dx = (b.second - a.second) * longitudeScale
                val dy = (b.first - a.first) * latitudeScale
                val px = (lng - a.second) * longitudeScale
                val py = (lat - a.first) * latitudeScale
                val lengthSquared = dx * dx + dy * dy
                val fraction = if (lengthSquared == 0.0) 0.0 else ((px * dx + py * dy) / lengthSquared).coerceIn(0.0, 1.0)
                closest = Position(index, fraction, distance)
            }
        }
        return closest
    }

    /** Road distance from the projected position to a maneuver vertex. */
    fun metersToVertex(points: List<Pair<Double, Double>>, position: Position, vertexIndex: Int): Float {
        if (vertexIndex <= position.segmentIndex) return 0f
        var remaining = 0f
        for (i in position.segmentIndex until vertexIndex.coerceAtMost(points.lastIndex)) {
            val length = GeoUtils.distanceMeters(points[i].first, points[i].second, points[i + 1].first, points[i + 1].second)
            remaining += if (i == position.segmentIndex) length * (1 - position.fraction).toFloat() else length
        }
        return remaining
    }
}
