package com.example.javisdriverpremium.data

import android.content.Context
import android.location.Geocoder
import com.example.javisdriverpremium.engine.GeoUtils
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

data class RouteStep(val lat: Double, val lng: Double, val instruction: String, val vertexIndex: Int)
data class RoutePlan(
    val points: List<Pair<Double, Double>>, val steps: List<RouteStep>,
    val meters: Double, val seconds: Double, val destinationLat: Double, val destinationLng: Double
)

/** Preview service for a single submitted destination. Call from Dispatchers.IO only. */
object RouteRepository {
    private val destinations = ConcurrentHashMap<String, Pair<Double, Double>>()

    fun plan(context: Context, originLat: Double, originLng: Double, destination: String): RoutePlan {
        val target = destination.trim().take(180)
        require(target.length >= 3) { "Nhập điểm đến cụ thể hơn." }
        require(originLat in -90.0..90.0 && originLng in -180.0..180.0)
        val searchKey = "${target.lowercase(Locale.ROOT)}:${originLat.toInt()}:${originLng.toInt()}"
        val coordinates = destinations[searchKey] ?: geocode(context, target, originLat, originLng).also {
            destinations[searchKey] = it
        }
        return route(originLat, originLng, coordinates.first, coordinates.second)
    }

    private fun geocode(context: Context, target: String, originLat: Double, originLng: Double): Pair<Double, Double> {
        if (Geocoder.isPresent()) {
            try {
                @Suppress("DEPRECATION")
                val address = Geocoder(context, Locale.forLanguageTag("vi-VN"))
                    .getFromLocationName(target, 5, 20.2, 104.0, 23.0, 106.6)
                    ?.filter { it.latitude in 20.2..23.0 && it.longitude in 104.0..106.6 }
                    ?.minByOrNull { GeoUtils.distanceMeters(originLat, originLng, it.latitude, it.longitude) }
                if (address != null) {
                    return address.latitude to address.longitude
                }
            } catch (_: Exception) { /* The system geocoder may be unavailable on some devices. */ }
        }
        // A fallback query is made only on an explicit user request; results are cached.
        val matches = JSONArray(read("https://nominatim.openstreetmap.org/search?q=${URLEncoder.encode(target, "UTF-8")}&format=json&limit=1&countrycodes=vn&viewbox=104.0,23.0,106.6,20.2&bounded=1"))
        require(matches.length() > 0) { "Không tìm thấy điểm đến tại Hà Nội hoặc Phú Thọ. Hãy nhập thêm xã/phường và tỉnh." }
        val place = matches.getJSONObject(0)
        return place.getDouble("lat") to place.getDouble("lon")
    }

    /** Rerouting uses the original coordinates and does not geocode or autocomplete again. */
    fun reroute(originLat: Double, originLng: Double, previous: RoutePlan): RoutePlan =
        route(originLat, originLng, previous.destinationLat, previous.destinationLng)

    private fun route(originLat: Double, originLng: Double, destinationLat: Double, destinationLng: Double): RoutePlan {
        val routeData = JSONObject(read("https://router.project-osrm.org/route/v1/driving/$originLng,$originLat;$destinationLng,$destinationLat?overview=full&geometries=geojson&steps=true"))
        require(routeData.optString("code") == "Ok") { "Không tìm được tuyến đường lái xe." }
        val route = routeData.getJSONArray("routes").getJSONObject(0)
        val geometry = route.getJSONObject("geometry").getJSONArray("coordinates")
        val points = (0 until geometry.length()).map { i -> geometry.getJSONArray(i).let { it.getDouble(1) to it.getDouble(0) } }
        val steps = mutableListOf<RouteStep>()
        val legs = route.getJSONArray("legs")
        var previousVertex = 0
        for (i in 0 until legs.length()) {
            val list = legs.getJSONObject(i).getJSONArray("steps")
            for (j in 0 until list.length()) {
                val step = list.getJSONObject(j)
                val maneuver = step.getJSONObject("maneuver")
                val place = maneuver.getJSONArray("location")
                val stepLat = place.getDouble(1)
                val stepLng = place.getDouble(0)
                val vertex = (previousVertex until points.size).minByOrNull { index ->
                    GeoUtils.distanceMeters(stepLat, stepLng, points[index].first, points[index].second)
                } ?: previousVertex
                previousVertex = vertex
                steps += RouteStep(stepLat, stepLng, instruction(maneuver.optString("type"), maneuver.optString("modifier"), step.optString("name"), maneuver.optInt("exit")), vertex)
            }
        }
        require(points.size > 1)
        return RoutePlan(points, steps, route.getDouble("distance"), route.getDouble("duration"), destinationLat, destinationLng)
    }

    internal fun instruction(type: String, modifier: String, road: String, exit: Int): String {
        val action = when (type) {
            "arrive" -> "Đã đến nơi"
            "roundabout", "rotary" -> if (exit > 0) "Vào vòng xuyến, ra lối số $exit" else "Vào vòng xuyến"
            "depart" -> "Bắt đầu đi"
            else -> when (modifier) {
                "left", "slight left", "sharp left" -> "Rẽ trái"
                "right", "slight right", "sharp right" -> "Rẽ phải"
                "uturn" -> "Quay đầu"
                else -> "Đi tiếp"
            }
        }
        return if (road.isBlank() || type == "arrive") action else "$action vào $road"
    }

    private fun read(address: String): String {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 8_000
        connection.readTimeout = 12_000
        connection.setRequestProperty("User-Agent", "JAVISDriver/0.6 (https://github.com/toantrn565-design/javis-driver-premium)")
        try {
            require(connection.responseCode in 200..299) { "Dịch vụ tuyến đường không phản hồi (${connection.responseCode})." }
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally { connection.disconnect() }
    }
}
