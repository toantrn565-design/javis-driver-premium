package com.example.javisdriverpremium.engine

import com.example.javisdriverpremium.model.AlertPoint
import com.example.javisdriverpremium.model.GpsSample

object CommunityCameraMatcher {
    /** Unknown camera direction: only show a nearby forward reference, never a verified fine. */
    fun nearestAhead(gps: GpsSample, hasBearing: Boolean, points: List<AlertPoint>): Pair<AlertPoint, Float>? {
        if (gps.accuracy > 25f || gps.speedKmh < 5f || !hasBearing) return null
        return points.asSequence().map { point ->
            point to GeoUtils.distanceMeters(gps.lat, gps.lng, point.lat, point.lng)
        }.filter { (point, distance) ->
            distance in 80f..500f && GeoUtils.isPointAhead(gps.lat, gps.lng, gps.bearing, point.lat, point.lng)
        }.minByOrNull { it.second }
    }
}
