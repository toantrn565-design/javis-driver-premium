package com.example.javisdriverpremium.data

import android.content.Context
import com.example.javisdriverpremium.engine.GeoUtils
import com.example.javisdriverpremium.model.AlertPoint
import com.example.javisdriverpremium.model.AlertType
import com.example.javisdriverpremium.model.VerificationStatus
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** OSM locations are reference-only. Neither direction nor enforcement purpose is verified. */
object CommunityCameraRepository {
    private const val CACHE_MAX_AGE_MS = 24 * 60 * 60 * 1000L
    private const val CACHE_RADIUS_METERS = 6_000f

    fun nearby(context: Context, lat: Double, lng: Double): List<AlertPoint> {
        val preferences = context.getSharedPreferences("osm_camera_reference", Context.MODE_PRIVATE)
        val cachedAt = preferences.getLong("at", 0L)
        val cachedLat = preferences.getString("lat", "0")?.toDoubleOrNull() ?: 0.0
        val cachedLng = preferences.getString("lng", "0")?.toDoubleOrNull() ?: 0.0
        val cached = preferences.getString("points", null)
        val nearbyCache = cached != null && GeoUtils.distanceMeters(lat, lng, cachedLat, cachedLng) < CACHE_RADIUS_METERS
        if (nearbyCache && System.currentTimeMillis() - cachedAt < CACHE_MAX_AGE_MS) {
            return parse(JSONArray(cached ?: "[]"))
        }
        val query = "[out:json][timeout:20];node[\"highway\"=\"speed_camera\"](${lat - 0.08},${lng - 0.08},${lat + 0.08},${lng + 0.08});out;"
        val url = "https://overpass.private.coffee/api/interpreter?data=${URLEncoder.encode(query, "UTF-8")}"
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 7_000
        connection.readTimeout = 25_000
        connection.setRequestProperty("User-Agent", "JAVISDriver/0.6 (https://github.com/toantrn565-design/javis-driver-premium)")
        try {
            require(connection.responseCode in 200..299)
            val elements = JSONObject(connection.inputStream.bufferedReader().use { it.readText() }).getJSONArray("elements")
            val results = parse(elements)
            preferences.edit().putLong("at", System.currentTimeMillis())
                .putString("lat", lat.toString()).putString("lng", lng.toString())
                .putString("points", elements.toString()).apply()
            return results
        } catch (error: Exception) {
            if (nearbyCache && System.currentTimeMillis() - cachedAt < 7 * CACHE_MAX_AGE_MS) {
                return parse(JSONArray(cached ?: "[]"))
            }
            throw error
        } finally { connection.disconnect() }
    }

    private fun parse(elements: JSONArray): List<AlertPoint> = buildList {
        for (index in 0 until elements.length()) {
            val node = elements.optJSONObject(index) ?: continue
            if (node.optString("type") != "node") continue
            val latitude = node.optDouble("lat")
            val longitude = node.optDouble("lon")
            if (!latitude.isFinite() || !longitude.isFinite() || latitude !in 8.0..24.0 || longitude !in 102.0..110.0) continue
            val id = node.optLong("id")
            if (id <= 0L) continue
            add(AlertPoint("OSM_NODE_$id", latitude, longitude, AlertType.SPEED_CAMERA,
                verificationStatus = VerificationStatus.UNVERIFIED,
                source = "https://www.openstreetmap.org/node/$id"))
        }
    }
}
