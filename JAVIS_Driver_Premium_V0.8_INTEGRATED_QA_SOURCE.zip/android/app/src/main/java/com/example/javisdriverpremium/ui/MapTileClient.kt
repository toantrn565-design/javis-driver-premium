package com.example.javisdriverpremium.ui

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.net.HttpURLConnection
import java.net.URL

/** Fetches HTTPS map tiles with an identifiable client. Never intercepts other resources. */
open class MapTileClient : WebViewClient() {
    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
        val target = request.url
        val host = target.host ?: return null
        if (target.scheme != "https" || host !in setOf("tile.openstreetmap.org", "a.tile.openstreetmap.fr", "api.maptiler.com")) return null
        val connection = URL(target.toString()).openConnection() as HttpURLConnection
        connection.connectTimeout = 7_000
        connection.readTimeout = 10_000
        connection.setRequestProperty("User-Agent", "JAVISDriver/0.8 (https://github.com/toantrn565-design/javis-driver-premium)")
        return try {
            if (connection.responseCode !in 200..299) {
                connection.disconnect()
                unavailable()
            } else {
                val mime = if (target.path?.endsWith(".jpg") == true) "image/jpeg" else "image/png"
                WebResourceResponse(mime, null, connection.inputStream)
            }
        } catch (_: Exception) {
            connection.disconnect()
            unavailable()
        }
    }

    private fun unavailable() = WebResourceResponse(
        "text/plain", "UTF-8", 502, "Map tile unavailable", emptyMap(), "".byteInputStream()
    )
}
