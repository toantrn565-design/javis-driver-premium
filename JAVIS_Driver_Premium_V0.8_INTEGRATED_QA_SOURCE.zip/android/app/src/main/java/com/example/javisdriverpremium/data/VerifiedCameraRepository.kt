package com.example.javisdriverpremium.data

import android.content.Context
import android.util.Log
import com.example.javisdriverpremium.model.AlertPoint
import com.example.javisdriverpremium.model.VerificationStatus
import kotlinx.serialization.json.Json

object VerifiedCameraRepository {
    private val json = Json { ignoreUnknownKeys = true }

    /** Only review-approved, direction-aware points may trigger a voice alert. */
    fun load(context: Context): List<AlertPoint> = try {
        val content = context.assets.open("camera_points.json").bufferedReader().use { it.readText() }
        json.decodeFromString<List<AlertPoint>>(content).filter { point ->
            point.verificationStatus == VerificationStatus.VERIFIED &&
                !point.isTestFixture &&
                point.direction != null && point.direction in 0f..359.999f &&
                point.source.startsWith("https://www.openstreetmap.org/") &&
                point.lat in 19.0..23.0 && point.lng in 103.0..107.0
        }
    } catch (error: Exception) {
        Log.e("JAVIS_CAMERAS", "Cannot load verified camera points", error)
        emptyList()
    }
}
