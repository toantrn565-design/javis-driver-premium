package com.example.javisdriverpremium

import android.webkit.WebView
import android.content.ContentValues
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import androidx.activity.compose.setContent
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.example.javisdriverpremium.ui.MapTileClient
import com.example.javisdriverpremium.ui.JavisDriverApp
import com.example.javisdriverpremium.theme.JavisDriverPremiumTheme
import com.example.javisdriverpremium.service.DrivingState
import com.example.javisdriverpremium.model.GpsQuality
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Exercises the packaged WebView map and actual tile loading on an Android emulator. */
@RunWith(AndroidJUnit4::class)
class MapOnDeviceTest {
    @Test fun drivingScreenActuallyDisplaysMapTiles() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val packageName = instrumentation.targetContext.packageName
        for (permission in listOf("android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION", "android.permission.POST_NOTIFICATIONS")) {
            instrumentation.uiAutomation.executeShellCommand("pm grant $packageName $permission").close()
        }
        val scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            scenario.onActivity { activity ->
                activity.setContent {
                    JavisDriverPremiumTheme {
                        JavisDriverApp(
                            drivingState = DrivingState(isDriving = true, currentLat = 21.0285, currentLng = 105.8542,
                                accuracy = 5f, gpsStatus = GpsQuality.EXCELLENT),
                            onStartDrive = {}, onEndDrive = {}, onReportSubmit = {}, onSimulateGps = {},
                            onNavigate = {}, onSpeakNavigation = {}, onVoiceDestination = {}, voiceDestination = null
                        )
                    }
                }
            }
            var result = "map view missing"
            for (attempt in 1..70) {
                var mapView: WebView? = null
                scenario.onActivity { activity -> mapView = findWebView(activity.window.decorView) }
                if (mapView != null) {
                    result = evaluate(mapView!!, """(function(){
                      const tiles=[...document.querySelectorAll('img.tile')];
                      return JSON.stringify({width:document.getElementById('map').clientWidth,
                        loaded:tiles.filter(x=>x.complete&&x.naturalWidth>0).length,
                        requested:tiles.length});
                    })()""")
                    if (allTilesLoaded(result)) break
                }
                Thread.sleep(500)
            }
            assertTrue("Driving screen has missing map tiles: $result", allTilesLoaded(result))
        } finally { scenario.close() }
    }

    private fun findWebView(view: View): WebView? {
        if (view is WebView) return view
        if (view is ViewGroup) for (index in 0 until view.childCount) {
            findWebView(view.getChildAt(index))?.let { return it }
        }
        return null
    }

    @Test fun roadMapDisplaysRealPixelsAndRoute() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val packageName = instrumentation.targetContext.packageName
        for (permission in listOf("android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION", "android.permission.POST_NOTIFICATIONS")) {
            instrumentation.uiAutomation.executeShellCommand("pm grant $packageName $permission").close()
        }
        val scenario = ActivityScenario.launch(MainActivity::class.java)
        lateinit var webView: WebView
        try {
            scenario.onActivity { activity ->
                webView = WebView(activity).apply {
                    settings.javaScriptEnabled = true
                    webViewClient = MapTileClient()
                }
                activity.setContentView(webView)
                webView.loadUrl("file:///android_asset/driver_map.html")
            }
            // Android WebView loads the local page asynchronously; retry after layout.
            var result = ""
            for (attempt in 1..70) {
                result = evaluate(webView, """(function(){
                  if (typeof updateMap !== 'function') return 'waiting';
                  updateMap(21.0285,105.8542,'road','');
                  updateRoute([[21.0285,105.8542],[21.03,105.86]]);
                  const tiles=[...document.querySelectorAll('img.tile')];
                  return JSON.stringify({width:document.getElementById('map').clientWidth,
                    loaded:tiles.filter(x=>x.complete&&x.naturalWidth>0).length,
                    requested:tiles.length,route:routePoints.length,
                    status:document.getElementById('status').textContent});
                })()""")
                if (allTilesLoaded(result)) break
                Thread.sleep(500)
            }
            val screenshot = instrumentation.uiAutomation.takeScreenshot()
            val resolver = instrumentation.targetContext.contentResolver
            val image = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "javis-map-emulator.png")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/")
                }) ?: error("Cannot save map screenshot")
            resolver.openOutputStream(image)!!.use { screenshot.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            screenshot.recycle()
            assertTrue("Map requires all downloaded tile pixels; WebView result: $result", allTilesLoaded(result))
            assertTrue("Route geometry must reach the map: $result", result.contains("\\\"route\\\":2"))
        } finally {
            scenario.close()
        }
    }

    private fun evaluate(view: WebView, script: String): String {
        val latch = CountDownLatch(1)
        var result = ""
        view.post { view.evaluateJavascript(script) { result = it; latch.countDown() } }
        assertTrue("WebView JavaScript timed out", latch.await(10, TimeUnit.SECONDS))
        return result
    }

    private fun allTilesLoaded(result: String): Boolean {
        fun count(name: String) = result.substringAfter("\\\"$name\\\":", "")
            .takeWhile(Char::isDigit).toIntOrNull()
        val loaded = count("loaded") ?: return false
        val requested = count("requested") ?: return false
        return requested > 0 && loaded >= requested
    }
}
