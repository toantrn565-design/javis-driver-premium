package com.example.javisdriverpremium

import com.example.javisdriverpremium.engine.RouteDeviation
import org.junit.Assert.assertTrue
import org.junit.Test

class RouteDeviationTest {
    private val road = listOf(21.0000 to 105.0000, 21.0010 to 105.0000)

    @Test fun pointBetweenVerticesIsOnRoute() {
        assertTrue(RouteDeviation.meters(21.0005, 105.0000, road) < 2f)
    }

    @Test fun parallelStreetTriggersRerouteCandidate() {
        assertTrue(RouteDeviation.meters(21.0005, 105.0015, road) > 100f)
    }

    @Test fun projectedDistanceShrinksAsDriverMovesAlongRoad() {
        val first = RouteDeviation.nearest(21.0002, 105.0000, road)
        val second = RouteDeviation.nearest(21.0008, 105.0000, road)
        val earlier = RouteDeviation.metersToVertex(road, first, 1)
        val later = RouteDeviation.metersToVertex(road, second, 1)
        assertTrue(earlier > 75f)
        assertTrue(later < 30f)
    }
}
