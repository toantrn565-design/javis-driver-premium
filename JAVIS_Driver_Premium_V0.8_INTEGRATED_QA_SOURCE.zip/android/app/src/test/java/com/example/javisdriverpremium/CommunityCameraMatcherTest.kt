package com.example.javisdriverpremium

import com.example.javisdriverpremium.engine.CommunityCameraMatcher
import com.example.javisdriverpremium.model.AlertPoint
import com.example.javisdriverpremium.model.AlertType
import com.example.javisdriverpremium.model.GpsSample
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CommunityCameraMatcherTest {
    private val north = AlertPoint("north", 21.002, 105.0, AlertType.SPEED_CAMERA)
    private val south = AlertPoint("south", 20.998, 105.0, AlertType.SPEED_CAMERA)
    private val gps = GpsSample(21.0, 105.0, 40f, 0f, 7f)

    @Test fun ignoresCameraBehindAndPicksForwardReference() {
        assertEquals("north", CommunityCameraMatcher.nearestAhead(gps, true, listOf(south, north))?.first?.id)
    }

    @Test fun missingHeadingOrWeakGpsMustNotSuggestCamera() {
        assertNull(CommunityCameraMatcher.nearestAhead(gps, false, listOf(north)))
        assertNull(CommunityCameraMatcher.nearestAhead(gps.copy(accuracy = 70f), true, listOf(north)))
    }
}
